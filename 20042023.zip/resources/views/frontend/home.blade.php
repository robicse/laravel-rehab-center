@extends('layouts.app')

@section('content')
<h1>WelCome Home</h1>
@endsection
